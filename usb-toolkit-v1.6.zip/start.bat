@echo off
chcp 65001 >nul
title USB Toolkit v1.6

echo ================================
echo   Jinxian USB Toolkit v1.6
echo ================================
echo.

REM Check admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Need administrator privileges. Restarting...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo [*] Setting up SSH...
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0setup-ssh.ps1"

echo.
echo [*] Starting Pinggy reverse tunnel...
echo.
echo The tunnel will appear below. Send this line to Jinxian:
echo ================================

REM Create auto-Enter helper
cd.>%TEMP%\jx_e.vbs
echo Set WshShell = CreateObject("WScript.Shell") >> %TEMP%\jx_e.vbs
echo WshShell.Run "ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -p 443 -R 0:localhost:22 tcp@a.pinggy.io", 1, False >> %TEMP%\jx_e.vbs
echo WScript.Sleep 3000 >> %TEMP%\jx_e.vbs
echo WshShell.SendKeys "25035500~" >> %TEMP%\jx_e.vbs
cscript //nologo %TEMP%\jx_e.vbs

echo.
echo ================================
echo Tunnel closed.
pause
