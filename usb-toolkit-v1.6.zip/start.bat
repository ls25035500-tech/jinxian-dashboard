@echo off
chcp 65001 >nul
title USB Toolkit v1.6

echo ================================
echo   Jinxian USB Toolkit v1.6
echo ================================
echo.

REM Check admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Need administrator privileges. Restarting...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo [*] Setting up SSH...
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0setup-ssh.ps1"

echo.
echo [*] Starting Pinggy reverse tunnel...
echo.
echo The tunnel will appear below. Send this line to Jinxian:
echo ================================

REM Auto-skip Pinggy password prompt
cd.>%TEMP%\jx_e.txt
ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -o PasswordAuthentication=no -o KbdInteractiveAuthentication=no -p 443 -R 0:localhost:22 tcp@a.pinggy.io < %TEMP%\jx_e.txt

echo.
echo ================================
echo Tunnel closed.
pause
