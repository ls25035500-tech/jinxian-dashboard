USB Toolkit v1.6 - Jinxian Remote Repair

========================================

This USB drive auto-configures SSH on Windows
and creates a secure tunnel for Jinxian AI to
connect and repair the computer remotely.

HOW TO USE:
1. Plug this USB into the computer
2. Double-click start.bat
3. Click "Yes" when UAC prompt appears
4. Wait for the tunnel address to appear
5. Send the tcp://... line to Jinxian

WHAT IT DOES:
- Installs OpenSSH Server (if needed)
- Starts SSH service
- Opens firewall port 22
- Creates temp admin account (jxhelper / Jinxian@2026)
- Creates a secure reverse tunnel via Pinggy

TUNNEL:
The line will look like:
tcp://xxxxx.run.pinggy-free.link:PORT

Send this to Jinxian on Telegram or LINE.

CREDENTIALS:
Username: jxhelper
Password: Jinxian@2026

SECURITY:
- Tunnel auto-expires in 60 minutes
- Account has admin privileges (for repairs)
- Remove account after use:
  net user jxhelper /delete
