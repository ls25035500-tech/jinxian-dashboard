@echo off
chcp 65001 >nul
title USB Toolkit v1.6

echo ================================
echo   Jinxian USB Toolkit v1.6.1
echo   (NO autotype - manual password)
echo ================================
echo.

REM Check admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Need administrator privileges. Restarting...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo [*] Setting up SSH...
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0setup-ssh.ps1"

echo.
echo [*] Starting Pinggy reverse tunnel...
echo.
echo The tunnel address will appear below:
echo ================================

ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -o KbdInteractiveAuthentication=no -p 443 -R 0:localhost:22 tcp@a.pinggy.io

echo.
echo ================================
echo Tunnel closed.
pause
