USB Toolkit v1.6 - Jinxian Remote Repair

========================================

This USB drive auto-configures SSH on Windows
and creates a secure tunnel for Jinxian AI to
connect and repair the computer remotely.

HOW TO USE:
1. Plug this USB into the computer
2. Double-click start.bat
3. Click "Yes" when UAC prompt appears
4. Wait for the tunnel address to appear
5. Send the tcp://... line to Jinxian

WHAT IT DOES:
- Installs OpenSSH Server (if needed)
- Starts SSH service
- Opens firewall port 22
- Creates a secure reverse tunnel via Pinggy

TUNNEL:
The line will look like:
tcp://xxxxx.run.pinggy-free.link:PORT

Send this to Jinxian on Telegram or LINE.

SECURITY:
- Tunnel auto-expires in 60 minutes
- No permanent changes to the computer
- SSH password = Windows login password
