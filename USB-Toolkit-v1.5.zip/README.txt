Jinxian USB Toolkit v1.2
=========================

What it does:
  1. Enables Windows SSH Server (auto)
  2. Creates encrypted reverse tunnel to serveo.net
  3. Shows the port number - send to Jinxian for remote access

Requirements:
  - Windows 10 version 1809 or newer
  - Internet connection
  - Computer login password

How to use:
  1. Copy all files to USB root
  2. Plug USB into target computer
  3. Double-click start.bat
  4. Click "Yes" if UAC prompt appears
  5. Wait for "Forwarding TCP connections from serveo.net:XXXXX"
  6. Send port number + computer username + password to Jinxian
  7. Keep this window open (closing = disconnect)

Security:
  - Encrypted SSH tunnel
  - No software installed permanently
  - No ports opened on firewall
  - Closing window = instant disconnection
